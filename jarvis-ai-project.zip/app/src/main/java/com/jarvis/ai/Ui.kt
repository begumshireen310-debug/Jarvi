package com.jarvis.ai

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

object JC {
    val bg = Color(0xFF03060D)
    val panel = Color(0xFF0A1424)
    val blue = Color(0xFF00C8FF)
    val red = Color(0xFFFF2D4A)
    val text = Color(0xFFD6F4FF)
    val dim = Color(0xFF7C9BB0)
}

private const val CAPABILITIES =
    "WORKS (app khula ho + screen on):\n" +
    "• Mic dabakar Hindi / English / Hinglish me bolna\n" +
    "• AI jawab ko awaaz me sunna (valid API key + internet chahiye)\n" +
    "• YouTube / Google kholna, web search, samay aur tarikh batana\n\n" +
    "NOT SUPPORTED (Android allow nahi karta / is app me nahi hai):\n" +
    "• \"Hey JARVIS\" wake-word\n" +
    "• Screen off ya lock hone par sunna\n" +
    "• Phone unlock karna\n" +
    "• Doosre apps ko poora control karna (sirf link / app kholna)\n\n" +
    "Voice recognition Google ki speech service use karti hai; kuch phones par ye internet maangti hai."

@Composable
fun JarvisApp(c: JarvisController) {
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) c.startListening() else c.note("Microphone permission nahi mili. Voice ke liye zaroori hai; Chat me type kar sakte hain.")
    }
    val onMic: () -> Unit = {
        when {
            c.state == JState.LISTENING -> c.stopListening()
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED -> c.startListening()
            else -> permLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }
    Column(Modifier.fillMaxSize().background(JC.bg).systemBarsPadding()) {
        Box(Modifier.weight(1f)) {
            when (tab) {
                0 -> DashboardScreen(c, onMic)
                1 -> ChatScreen(c, onMic)
                else -> SettingsScreen(c)
            }
        }
        NavBar(tab) { tab = it }
    }
}

@Composable
fun NavBar(selected: Int, onSelect: (Int) -> Unit) {
    val items = listOf("DASHBOARD", "CHAT", "SETTINGS")
    Row(Modifier.fillMaxWidth().background(JC.panel).border(1.dp, JC.blue.copy(alpha = 0.3f))) {
        items.forEachIndexed { i, label ->
            Box(
                Modifier.weight(1f).clickable { onSelect(i) }.padding(vertical = 14.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(label, color = if (i == selected) JC.blue else JC.dim, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            }
        }
    }
}

@Composable
fun HudCard(modifier: Modifier = Modifier, accent: Color = JC.blue, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(12.dp)).background(JC.panel)
            .border(1.dp, accent.copy(alpha = 0.45f), RoundedCornerShape(12.dp)).padding(12.dp),
        content = content
    )
}

@Composable
fun HudButton(label: String, modifier: Modifier = Modifier, color: Color = JC.blue, filled: Boolean = false, onClick: () -> Unit) {
    Box(
        modifier.clip(RoundedCornerShape(10.dp))
            .background(if (filled) color.copy(alpha = 0.25f) else Color.Transparent)
            .border(1.dp, color, RoundedCornerShape(10.dp))
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) { Text(label, color = color, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center) }
}

@Composable
fun AiOrb(state: JState, level: Float, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "orb")
    val spin by t.animateFloat(0f, 360f, infiniteRepeatable(tween(12000, easing = LinearEasing)), label = "spin")
    val spin2 by t.animateFloat(360f, 0f, infiniteRepeatable(tween(7000, easing = LinearEasing)), label = "spin2")
    val pulse by t.animateFloat(
        0.92f, 1.08f, infiniteRepeatable(tween(1600, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse"
    )
    val smooth by animateFloatAsState(level, label = "lvl")
    val main = if (state == JState.LISTENING) JC.red else JC.blue
    val second = if (state == JState.LISTENING) JC.blue else JC.red

    Canvas(modifier.aspectRatio(1f).clip(CircleShape).clickable(onClick = onClick)) {
        val c = center
        val r = size.minDimension / 2f
        drawCircle(Brush.radialGradient(listOf(main.copy(alpha = 0.40f), Color.Transparent), center = c, radius = r), radius = r)
        drawCircle(main.copy(alpha = 0.5f), radius = r * 0.92f, style = Stroke(2.dp.toPx()))

        rotate(spin, c) {
            val s = Size(r * 1.6f, r * 1.6f)
            val tl = Offset(c.x - r * 0.8f, c.y - r * 0.8f)
            drawArc(main, 0f, 90f, false, tl, s, style = Stroke(6.dp.toPx(), cap = StrokeCap.Round))
            drawArc(main, 180f, 60f, false, tl, s, style = Stroke(6.dp.toPx(), cap = StrokeCap.Round))
        }
        rotate(spin2, c) {
            val s = Size(r * 1.36f, r * 1.36f)
            val tl = Offset(c.x - r * 0.68f, c.y - r * 0.68f)
            drawArc(second, 40f, 50f, false, tl, s, style = Stroke(5.dp.toPx(), cap = StrokeCap.Round))
            drawArc(main, 200f, 80f, false, tl, s, style = Stroke(3.dp.toPx(), cap = StrokeCap.Round))
        }
        rotate(spin * 0.5f, c) {
            for (i in 0 until 60) {
                val a = Math.toRadians(i * 6.0)
                val inner = r * 0.86f
                val outer = if (i % 5 == 0) r * 0.78f else r * 0.82f
                drawLine(
                    main.copy(alpha = 0.6f),
                    Offset(c.x + cos(a).toFloat() * inner, c.y + sin(a).toFloat() * inner),
                    Offset(c.x + cos(a).toFloat() * outer, c.y + sin(a).toFloat() * outer),
                    1.5.dp.toPx()
                )
            }
        }
        val coreR = r * 0.42f * pulse * (1f + smooth * 0.25f)
        drawCircle(
            Brush.radialGradient(listOf(Color.White.copy(alpha = 0.9f), main, main.copy(alpha = 0.1f)), center = c, radius = coreR),
            radius = coreR
        )
    }
}

@Composable
fun Waveform(state: JState, level: Float, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "wf")
    val phase by t.animateFloat(0f, (2 * PI).toFloat(), infiniteRepeatable(tween(1400, easing = LinearEasing)), label = "p")
    val color = if (state == JState.LISTENING) JC.red else JC.blue
    val amp = when (state) {
        JState.LISTENING -> 0.15f + level * 0.85f
        JState.SPEAKING -> 0.55f
        JState.THINKING -> 0.25f
        JState.IDLE -> 0.06f
    }
    Canvas(modifier) {
        val n = 40
        val gap = size.width / n
        for (i in 0 until n) {
            val h = max(size.height * amp * (0.35f + 0.65f * abs(sin(phase + i * 0.45f))), 3.dp.toPx())
            val x = gap * i + gap / 2f
            drawLine(color, Offset(x, size.height / 2f - h / 2f), Offset(x, size.height / 2f + h / 2f), gap * 0.5f, StrokeCap.Round)
        }
    }
}

@Composable
fun DashboardScreen(c: JarvisController, onMic: () -> Unit) {
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) { while (true) { now = Date(); delay(1000) } }
    val status = when (c.state) {
        JState.IDLE -> "STANDBY — tap the core and speak"
        JState.LISTENING -> "LISTENING…"
        JState.THINKING -> "THINKING…"
        JState.SPEAKING -> "SPEAKING…"
    }
    val last = c.messages.lastOrNull { it.role != Role.USER }?.text ?: ""
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("J.A.R.V.I.S  AI", color = JC.blue, fontSize = 26.sp, fontWeight = FontWeight.Bold, letterSpacing = 6.sp)
        Text(status, color = if (c.state == JState.LISTENING) JC.red else JC.dim, fontSize = 12.sp, letterSpacing = 2.sp)
        AiOrb(c.state, c.level, onMic, Modifier.fillMaxWidth(0.72f))
        Waveform(c.state, c.level, Modifier.fillMaxWidth().height(56.dp))
        HudButton(
            if (c.state == JState.LISTENING) "■  STOP" else "🎤  SPEAK",
            Modifier.fillMaxWidth(0.6f),
            color = if (c.state == JState.LISTENING) JC.red else JC.blue,
            filled = true,
            onClick = onMic
        )
        if (last.isNotBlank()) {
            HudCard(Modifier.fillMaxWidth(), accent = JC.red) {
                Text("LAST RESPONSE", color = JC.red, fontSize = 10.sp, letterSpacing = 2.sp)
                Text(last, color = JC.text, fontSize = 14.sp, maxLines = 6)
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            HudCard(Modifier.weight(1f)) {
                Text("TIME", color = JC.dim, fontSize = 10.sp, letterSpacing = 2.sp)
                Text(SimpleDateFormat("hh:mm:ss a", Locale.ENGLISH).format(now), color = JC.text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
            HudCard(Modifier.weight(1f)) {
                Text("DATE", color = JC.dim, fontSize = 10.sp, letterSpacing = 2.sp)
                Text(SimpleDateFormat("EEE, d MMM yyyy", Locale.ENGLISH).format(now), color = JC.text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            HudCard(Modifier.weight(1f), accent = if (c.apiKeySet) JC.blue else JC.red) {
                Text("AI LINK", color = JC.dim, fontSize = 10.sp, letterSpacing = 2.sp)
                Text(
                    if (c.apiKeySet) "KEY SET" else "NO API KEY",
                    color = if (c.apiKeySet) JC.blue else JC.red, fontSize = 15.sp, fontWeight = FontWeight.Bold
                )
            }
            HudCard(Modifier.weight(1f)) {
                Text("LANGUAGE", color = JC.dim, fontSize = 10.sp, letterSpacing = 2.sp)
                Text(c.lang.label, color = JC.text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
        }
        Text("QUICK COMMANDS", color = JC.dim, fontSize = 10.sp, letterSpacing = 2.sp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            HudButton("YouTube", Modifier.weight(1f)) { c.submit("open youtube") }
            HudButton("Google", Modifier.weight(1f)) { c.submit("open google") }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            HudButton("Time?", Modifier.weight(1f), color = JC.red) { c.submit("what time is it") }
            HudButton("Date?", Modifier.weight(1f), color = JC.red) { c.submit("what is the date") }
        }
        HudCard(Modifier.fillMaxWidth()) {
            Text("HONEST CAPABILITIES", color = JC.blue, fontSize = 10.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(6.dp))
            Text(CAPABILITIES, color = JC.text, fontSize = 12.sp, lineHeight = 17.sp)
        }
    }
}

@Composable
fun ChatScreen(c: JarvisController, onMic: () -> Unit) {
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    LaunchedEffect(c.messages.size) { if (c.messages.isNotEmpty()) listState.animateScrollToItem(c.messages.size - 1) }
    val send = { if (input.isNotBlank()) { c.submit(input); input = "" } }

    Column(Modifier.fillMaxSize().imePadding()) {
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp),
            state = listState,
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(vertical = 12.dp)
        ) {
            items(c.messages) { m ->
                val color = when (m.role) { Role.USER -> JC.red; Role.AI -> JC.blue; Role.SYSTEM -> JC.dim }
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = if (m.role == Role.USER) Arrangement.End else Arrangement.Start
                ) {
                    Box(
                        Modifier.widthIn(max = 300.dp).clip(RoundedCornerShape(14.dp)).background(color.copy(alpha = 0.12f))
                            .border(1.dp, color.copy(alpha = 0.6f), RoundedCornerShape(14.dp)).padding(12.dp)
                    ) { Text(m.text, color = JC.text, fontSize = 14.sp) }
                }
            }
            if (c.state == JState.THINKING) {
                item { Text("JARVIS soch raha hai…", color = JC.dim, fontSize = 12.sp) }
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Type a message…", color = JC.dim) },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { send() }),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = JC.text, unfocusedTextColor = JC.text,
                    focusedBorderColor = JC.blue, unfocusedBorderColor = JC.blue.copy(alpha = 0.4f), cursorColor = JC.blue
                )
            )
            HudButton("🎤", color = JC.red, onClick = onMic)
            HudButton("SEND", filled = true, onClick = { send() })
        }
    }
}

@Composable
fun SettingsScreen(c: JarvisController) {
    val ctx = LocalContext.current
    var key by remember { mutableStateOf(c.settings.apiKey) }
    var model by remember { mutableStateOf(c.settings.model) }
    var lang by remember { mutableStateOf(c.settings.lang) }
    var speak by remember { mutableStateOf(c.settings.speakReplies) }
    var saved by remember { mutableStateOf(false) }
    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedTextColor = JC.text, unfocusedTextColor = JC.text,
        focusedBorderColor = JC.blue, unfocusedBorderColor = JC.blue.copy(alpha = 0.4f), cursorColor = JC.blue,
        focusedLabelColor = JC.blue, unfocusedLabelColor = JC.dim
    )
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("SETTINGS", color = JC.blue, fontSize = 22.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
        HudCard(Modifier.fillMaxWidth()) {
            Text("AI API KEY (Google Gemini)", color = JC.blue, fontSize = 11.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = key, onValueChange = { key = it; saved = false },
                label = { Text("API key") }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth(), colors = fieldColors
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = model, onValueChange = { model = it; saved = false },
                label = { Text("Model name") }, singleLine = true,
                modifier = Modifier.fillMaxWidth(), colors = fieldColors
            )
            Spacer(Modifier.height(8.dp))
            HudButton("Get a free key (aistudio.google.com)", Modifier.fillMaxWidth()) {
                openLink(ctx, "https://aistudio.google.com/apikey")
            }
            Spacer(Modifier.height(6.dp))
            Text(
                "Key sirf is phone ki app-private storage me save hoti hai. Chat ka text AI jawab ke liye Google ko bheja jata hai.",
                color = JC.dim, fontSize = 11.sp
            )
        }
        HudCard(Modifier.fillMaxWidth()) {
            Text("LANGUAGE", color = JC.blue, fontSize = 11.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Lang.values().forEach { l ->
                    HudButton(l.label, Modifier.weight(1f), color = if (l == lang) JC.red else JC.blue, filled = l == lang) {
                        lang = l; saved = false
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Speak replies aloud", color = JC.text, modifier = Modifier.weight(1f))
                Switch(checked = speak, onCheckedChange = { speak = it; saved = false })
            }
        }
        HudButton("SAVE SETTINGS", Modifier.fillMaxWidth(), filled = true) {
            c.saveSettings(key, model, lang, speak)
            saved = true
        }
        if (saved) Text("✔ Saved on this phone.", color = JC.blue, fontSize = 13.sp)
        HudCard(Modifier.fillMaxWidth()) {
            Text("HONEST CAPABILITIES", color = JC.blue, fontSize = 10.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(6.dp))
            Text(CAPABILITIES, color = JC.text, fontSize = 12.sp, lineHeight = 17.sp)
        }
    }
}

private fun openLink(ctx: Context, url: String) {
    try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {
    }
}

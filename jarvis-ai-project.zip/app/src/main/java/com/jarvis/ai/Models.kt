package com.jarvis.ai

import android.content.Context

enum class Role { USER, AI, SYSTEM }

data class ChatMessage(val text: String, val role: Role)

enum class JState { IDLE, LISTENING, THINKING, SPEAKING }

enum class Lang(val label: String, val recognitionTag: String, val ttsTag: String) {
    HINDI("हिन्दी", "hi-IN", "hi-IN"),
    ENGLISH("English", "en-IN", "en-IN"),
    // Hinglish: speech is recognised with the Hindi model, replies are written in Roman script
    HINGLISH("Hinglish", "hi-IN", "en-IN")
}

/** Settings are stored locally on the phone (app-private storage). Nothing is uploaded except your chat text sent to the AI API. */
class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("jarvis_settings", Context.MODE_PRIVATE)

    var apiKey: String
        get() = prefs.getString("api_key", "") ?: ""
        set(v) = prefs.edit().putString("api_key", v.trim()).apply()

    var model: String
        get() = prefs.getString("model", "gemini-2.5-flash") ?: "gemini-2.5-flash"
        set(v) = prefs.edit().putString("model", v.trim().ifEmpty { "gemini-2.5-flash" }).apply()

    var lang: Lang
        get() = runCatching { Lang.valueOf(prefs.getString("lang", Lang.HINGLISH.name)!!) }.getOrDefault(Lang.HINGLISH)
        set(v) = prefs.edit().putString("lang", v.name).apply()

    var speakReplies: Boolean
        get() = prefs.getBoolean("speak", true)
        set(v) = prefs.edit().putBoolean("speak", v).apply()
}

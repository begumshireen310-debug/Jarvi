package com.jarvis.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Talks to the Google Gemini API (free tier available with a free key from aistudio.google.com/apikey). */
object AiClient {

    private fun systemPrompt(lang: Lang): String {
        val style = when (lang) {
            Lang.HINDI -> "Reply in simple Hindi written in Devanagari script."
            Lang.ENGLISH -> "Reply in simple English."
            Lang.HINGLISH -> "Reply in Hinglish: Hindi written in Roman (English) letters, mixing common English words."
        }
        return "You are JARVIS, a helpful, calm and witty personal voice assistant. $style " +
            "Keep answers short (1 to 4 sentences) because they will be read aloud. " +
            "Do not use markdown, bullet symbols or emojis. Never claim you can control the phone beyond what the user asked."
    }

    suspend fun ask(apiKey: String, model: String, lang: Lang, history: List<ChatMessage>): String =
        withContext(Dispatchers.IO) {
            val turns = history.filter { it.role != Role.SYSTEM }.takeLast(12).dropWhile { it.role != Role.USER }
            if (turns.isEmpty()) throw IOException("Nothing to send.")

            val contents = JSONArray()
            for (m in turns) {
                contents.put(
                    JSONObject()
                        .put("role", if (m.role == Role.USER) "user" else "model")
                        .put("parts", JSONArray().put(JSONObject().put("text", m.text)))
                )
            }
            val body = JSONObject()
                .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt(lang)))))
                .put("contents", contents)

            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/${model.trim()}:generateContent")
            val conn = url.openConnection() as HttpURLConnection
            try {
                conn.requestMethod = "POST"
                conn.connectTimeout = 15000
                conn.readTimeout = 45000
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json")
                conn.setRequestProperty("x-goog-api-key", apiKey.trim())
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                if (code !in 200..299) {
                    val msg = runCatching { JSONObject(text).getJSONObject("error").getString("message") }.getOrDefault(text.take(200))
                    val hint = when (code) {
                        400, 401, 403 -> " (API key galat ya band hai / key invalid)"
                        404 -> " (model ka naam galat hai / wrong model name)"
                        429 -> " (free limit khatam, thodi der baad try karein / rate limit)"
                        else -> ""
                    }
                    throw IOException("AI error $code$hint: $msg")
                }
                val parts = JSONObject(text).getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts")
                val sb = StringBuilder()
                for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
                sb.toString().trim().ifEmpty { throw IOException("AI ne khali jawab diya (empty reply).") }
            } finally {
                conn.disconnect()
            }
        }
}

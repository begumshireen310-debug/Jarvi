package com.jarvis.ai

import android.content.Context
import android.content.Intent
import android.net.Uri
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Handles simple built-in commands locally. Returns the reply text, or null if the AI should answer. */
object CommandRouter {

    private val noise = setOf(
        "open", "kholo", "khol", "do", "jarvis", "please", "search", "khojo", "dhundo", "dhoondo",
        "on", "par", "for", "play", "chalao", "chala", "the", "pe", "mein", "me", "karo", "kar", "ko",
        "youtube", "google", "and", "aur", "a", "an", "to", "in",
        "खोलो", "खोल", "दो", "जार्विस", "सर्च", "खोजो", "ढूंढो", "ढूँढो", "पर", "चलाओ", "चला", "में", "पे",
        "करो", "को", "यूट्यूब", "गूगल", "और"
    )

    private fun has(s: String, vararg k: String) = k.any { s.contains(it) }

    private fun tr(l: Lang, hi: String, en: String, hing: String) = when (l) {
        Lang.HINDI -> hi
        Lang.ENGLISH -> en
        Lang.HINGLISH -> hing
    }

    private fun query(s: String): String =
        s.split(Regex("\\s+")).filter { it.isNotBlank() && it !in noise }.joinToString(" ")

    private fun openUrl(ctx: Context, url: String, pkg: String? = null): Boolean {
        fun start(p: String?): Boolean = try {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (p != null) i.setPackage(p)
            ctx.startActivity(i)
            true
        } catch (e: Exception) {
            false
        }
        return (pkg != null && start(pkg)) || start(null)
    }

    fun handle(ctx: Context, raw: String, lang: Lang): String? {
        val s = raw.lowercase(Locale.ROOT).trim()
        val isYt = has(s, "youtube", "यूट्यूब", "यू ट्यूब")
        val isGoogle = has(s, "google", "गूगल")
        val isSearch = has(s, "search", "सर्च", "khojo", "खोजो", "dhundo", "dhoondo", "ढूंढो", "ढूँढो")
        val isOpen = has(s, "open", "kholo", "khol", "खोलो", "खोल")
        val isPlay = has(s, "play", "chalao", "चलाओ")

        if (isYt && (isOpen || isSearch || isPlay)) {
            val q = query(s)
            val ok = if (q.isBlank()) openUrl(ctx, "https://www.youtube.com", "com.google.android.youtube")
            else openUrl(ctx, "https://www.youtube.com/results?search_query=" + Uri.encode(q), "com.google.android.youtube")
            return if (!ok) tr(lang, "YouTube नहीं खुल पाया।", "Could not open YouTube.", "YouTube nahi khul paya.")
            else if (q.isBlank()) tr(lang, "YouTube खोल रहा हूँ।", "Opening YouTube.", "YouTube khol raha hoon.")
            else tr(lang, "YouTube पर $q खोज रहा हूँ।", "Searching YouTube for $q.", "YouTube par $q search kar raha hoon.")
        }

        if (isGoogle && (isOpen || isSearch)) {
            val q = query(s)
            val ok = if (q.isBlank()) openUrl(ctx, "https://www.google.com")
            else openUrl(ctx, "https://www.google.com/search?q=" + Uri.encode(q))
            return if (!ok) tr(lang, "Google नहीं खुल पाया।", "Could not open Google.", "Google nahi khul paya.")
            else if (q.isBlank()) tr(lang, "Google खोल रहा हूँ।", "Opening Google.", "Google khol raha hoon.")
            else tr(lang, "Google पर $q खोज रहा हूँ।", "Searching Google for $q.", "Google par $q search kar raha hoon.")
        }

        if (isSearch) {
            val q = query(s)
            if (q.isNotBlank()) {
                val ok = openUrl(ctx, "https://www.google.com/search?q=" + Uri.encode(q))
                return if (ok) tr(lang, "वेब पर $q खोज रहा हूँ।", "Searching the web for $q.", "Web par $q search kar raha hoon.")
                else tr(lang, "ब्राउज़र नहीं खुल पाया।", "Could not open the browser.", "Browser nahi khul paya.")
            }
        }

        if (has(s, "what time", "the time", "current time", "time kya", "samay", "समय", "kitne baje", "कितने बजे", "टाइम")) {
            val t = SimpleDateFormat("hh:mm a", Locale.ENGLISH).format(Date())
            return tr(lang, "अभी समय है $t।", "The time is $t.", "Abhi samay hai $t.")
        }

        if (Regex("\\bdate\\b").containsMatchIn(s) ||
            has(s, "what day", "which day", "tarikh", "तारीख", "तारिख", "कौन सा दिन", "kaun sa din", "din kya")
        ) {
            val loc = if (lang == Lang.HINDI) Locale.forLanguageTag("hi-IN") else Locale.ENGLISH
            val d = SimpleDateFormat("EEEE, d MMMM yyyy", loc).format(Date())
            return tr(lang, "आज $d है।", "Today is $d.", "Aaj $d hai.")
        }
        return null
    }
}

package com.jarvis.ai

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import java.net.UnknownHostException
import java.util.Locale

class JarvisController(private val ctx: Context, private val scope: CoroutineScope) {

    val settings = SettingsStore(ctx)
    val messages = mutableStateListOf<ChatMessage>()

    var state by mutableStateOf(JState.IDLE)
        private set
    var level by mutableFloatStateOf(0f)
        private set
    var lang by mutableStateOf(settings.lang)
        private set
    var apiKeySet by mutableStateOf(settings.apiKey.isNotBlank())
        private set

    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    init {
        messages.add(
            ChatMessage(
                "Namaste! Main JARVIS hoon. Mic dabakar bolein ya neeche type karein. " +
                    "(Voice sirf tab kaam karti hai jab app khula ho aur screen on ho.)",
                Role.SYSTEM
            )
        )
        tts = TextToSpeech(ctx) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) {
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) { main.post { if (state == JState.SPEAKING) state = JState.IDLE } }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { main.post { if (state == JState.SPEAKING) state = JState.IDLE } }
                })
            }
        }
    }

    fun note(text: String) { messages.add(ChatMessage(text, Role.SYSTEM)) }

    fun saveSettings(key: String, model: String, newLang: Lang, speak: Boolean) {
        settings.apiKey = key
        settings.model = model
        settings.lang = newLang
        settings.speakReplies = speak
        lang = newLang
        apiKeySet = settings.apiKey.isNotBlank()
    }

    // ---------- Voice input ----------
    fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            note("Is phone par speech recognition service nahi mili. Google app / Google Speech Services install ya update karein. Tab tak Chat me type karein.")
            return
        }
        stopSpeaking()
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) { level = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f) }
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { level = 0f }
            override fun onError(error: Int) {
                level = 0f
                state = JState.IDLE
                when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                        note("Kuch suna nahi gaya. Mic dabakar dobara bolein.")
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> note("Microphone permission chahiye.")
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                        note("Speech recognition ke liye internet chahiye ho sakta hai. Connection check karein.")
                    SpeechRecognizer.ERROR_CLIENT -> {}
                    else -> note("Voice error (code $error). Dobara try karein.")
                }
            }
            override fun onResults(results: Bundle?) {
                level = 0f
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                state = JState.IDLE
                if (text.isNullOrBlank()) note("Kuch suna nahi gaya.") else submit(text)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, settings.lang.recognitionTag)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        state = JState.LISTENING
        r.startListening(i)
    }

    fun stopListening() {
        recognizer?.stopListening()
        level = 0f
        if (state == JState.LISTENING) state = JState.IDLE
    }

    // ---------- Handling a command or question (typed or spoken) ----------
    fun submit(input: String) {
        val t = input.trim()
        if (t.isEmpty()) return
        stopSpeaking()
        messages.add(ChatMessage(t, Role.USER))

        val local = CommandRouter.handle(ctx, t, settings.lang)
        if (local != null) {
            reply(local)
            return
        }
        if (settings.apiKey.isBlank()) {
            note("AI jawab dene ke liye API key chahiye. Settings tab me free Gemini API key daalein. (Bina key ke AI kaam nahi karega. Time, date, YouTube, Google commands bina key ke chalte hain.)")
            return
        }
        val snapshot = messages.toList()
        state = JState.THINKING
        scope.launch {
            try {
                val answer = AiClient.ask(settings.apiKey, settings.model, settings.lang, snapshot)
                reply(answer)
            } catch (e: UnknownHostException) {
                state = JState.IDLE
                note("Internet nahi hai, isliye AI se connect nahi ho paya.")
            } catch (e: Exception) {
                state = JState.IDLE
                note(e.message ?: "AI se connect nahi ho paya.")
            }
        }
    }

    private fun reply(text: String) {
        messages.add(ChatMessage(text, Role.AI))
        if (settings.speakReplies) speak(text) else state = JState.IDLE
    }

    // ---------- Voice output ----------
    private fun speak(text: String) {
        val engine = tts
        if (engine == null || !ttsReady) {
            state = JState.IDLE
            note("Text-to-speech engine ready nahi hai (phone ki Settings me TTS engine check karein).")
            return
        }
        val res = engine.setLanguage(Locale.forLanguageTag(settings.lang.ttsTag))
        if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
            note("Is bhasha ki awaaz phone me install nahi hai. Phone Settings > Text-to-speech me voice data download karein.")
        }
        val clean = text.replace(Regex("[*#`_]"), "").take(3500)
        state = JState.SPEAKING
        engine.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    fun stopSpeaking() {
        tts?.stop()
        if (state == JState.SPEAKING) state = JState.IDLE
    }

    fun release() {
        recognizer?.destroy()
        recognizer = null
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}

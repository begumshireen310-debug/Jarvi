package com.jarvis.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.lifecycleScope

class MainActivity : ComponentActivity() {
    private lateinit var controller: JarvisController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        controller = JarvisController(this, lifecycleScope)
        setContent { JarvisApp(controller) }
    }

    override fun onStop() {
        super.onStop()
        // Android does not allow normal apps to keep listening once the app is not on screen.
        controller.stopListening()
    }

    override fun onDestroy() {
        controller.release()
        super.onDestroy()
    }
}

package com.example.jarvis

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.util.Locale

private val Navy = Color(0xFF050B16)
private val Panel = Color(0xFF0C1A2C)
private val Cyan = Color(0xFF35D9FF)
private val SoftText = Color(0xFFB8D7E8)

data class ChatLine(val fromUser: Boolean, val text: String)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var speechCallback: ((String) -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent { JarvisScreen(onSpeak = { speak(it) }, onListen = { callback -> startListening(callback) }, onCommand = { runCommand(it) }) }
    }

    override fun onInit(status: Int) { if (status == TextToSpeech.SUCCESS) tts?.language = Locale.getDefault() }

    private fun speak(text: String) { tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply") }

    private fun startListening(callback: (String) -> Unit) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            callback("MIC_PERMISSION_NEEDED"); return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { callback("Speech recognition is not available on this phone."); return }
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { callback("I couldn't hear that clearly. Please try again.") }
            override fun onResults(results: Bundle?) {
                val heard = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                callback(heard.ifBlank { "I didn't catch that." })
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to JARVIS")
        }
        speechRecognizer?.startListening(intent)
    }

    private fun runCommand(raw: String): String {
        val q = raw.trim()
        val lower = q.lowercase(Locale.ROOT)
        if (lower.contains("youtube") && (lower.contains("open") || lower.contains("खोल") || lower == "youtube")) {
            val launch = packageManager.getLaunchIntentForPackage("com.google.android.youtube")
            if (launch != null) startActivity(launch) else startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com")))
            return "Opening YouTube."
        }
        if (lower.contains("search") || lower.contains("सर्च") || lower.contains("ढूंढ") || lower.contains("खोज")) {
            val query = q.replace(Regex("(?i)open|search|youtube|पर|में|सर्च|खोलो|खोलना|ढूंढो|खोजो"), " ").trim().ifBlank { q }
            val url = if (lower.contains("youtube") || lower.contains("यूट्यूब")) "https://www.youtube.com/results?search_query=${Uri.encode(query)}" else "https://www.google.com/search?q=${Uri.encode(query)}"
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            return "Searching for $query."
        }
        if (lower.contains("hello") || lower.contains("नमस्ते") || lower.contains("सलाम") || lower.contains("hi jarvis")) return "Hello! JARVIS online. बताइए, मैं क्या करूँ?"
        if (lower.contains("time") || lower.contains("समय") || lower.contains("टाइम")) return "अभी समय ${java.text.SimpleDateFormat("h:mm a", Locale.getDefault()).format(java.util.Date())} है।"
        return "मैंने सुना: $q. अभी मेरे पास basic offline commands हैं; open YouTube या search YouTube बोलकर देखें।"
    }

    override fun onDestroy() { speechRecognizer?.destroy(); tts?.shutdown(); super.onDestroy() }
}

@Composable
private fun JarvisScreen(onSpeak: (String) -> Unit, onListen: ((String) -> Unit) -> Unit, onCommand: (String) -> String) {
    val context = LocalContext.current
    var input by remember { mutableStateOf("") }
    var listening by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var voiceReplies by remember { mutableStateOf(true) }
    var language by remember { mutableStateOf("Hindi / Hinglish") }
    val history = remember { mutableStateListOf(ChatLine(false, "JARVIS systems online. नमस्ते! नीचे लिखें या mic दबाकर बोलें।")) }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) { listening = true; onListen { result -> listening = false; if (result != "MIC_PERMISSION_NEEDED") { input = result } } }
        else history.add(ChatLine(false, "Microphone permission नहीं मिली। Settings में जाकर अनुमति दें।"))
    }
    fun submit(text: String) {
        val clean = text.trim(); if (clean.isBlank()) return
        history.add(ChatLine(true, clean)); input = ""
        val answer = onCommand(clean)
        history.add(ChatLine(false, answer)); if (voiceReplies) onSpeak(answer)
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Navy, surface = Panel)) {
        Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF071525), Navy, Color(0xFF02050B))).padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Box(Modifier.size(48.dp).border(1.dp, Cyan, CircleShape).background(Panel, CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.SmartToy, null, tint = Cyan, modifier = Modifier.size(28.dp)) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) { Text("J.A.R.V.I.S", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold); Text("PERSONAL ASSISTANT  •  ANDROID", color = Cyan, fontSize = 10.sp, letterSpacing = 1.2.sp) }
                IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, "Settings", tint = SoftText) }
            }
            Spacer(Modifier.height(16.dp))
            Box(Modifier.fillMaxWidth().border(1.dp, Cyan.copy(alpha = .45f), RoundedCornerShape(18.dp)).background(Panel.copy(alpha = .85f), RoundedCornerShape(18.dp)).padding(16.dp), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.size(112.dp).border(2.dp, Cyan.copy(alpha = .75f), CircleShape).padding(8.dp).border(1.dp, Cyan.copy(alpha = .5f), CircleShape).background(Brush.radialGradient(listOf(Color(0xFF164B6A), Color(0xFF071525))), CircleShape), contentAlignment = Alignment.Center) { Text("J", color = Cyan, fontSize = 50.sp, fontWeight = FontWeight.Light) }
                    Spacer(Modifier.height(8.dp)); Text(if (listening) "LISTENING…" else "SYSTEM ONLINE", color = Cyan, fontSize = 12.sp, letterSpacing = 2.sp)
                    Text("Voice • Search • Quick commands", color = SoftText, fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(14.dp))
            Text("CONVERSATION", color = Cyan, fontSize = 11.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(history) { line ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (line.fromUser) Arrangement.End else Arrangement.Start) {
                        Column(Modifier.widthIn(max = 300.dp).border(1.dp, if (line.fromUser) Color(0xFF287AA0) else Cyan.copy(alpha = .25f), RoundedCornerShape(14.dp)).background(if (line.fromUser) Color(0xFF102D43) else Panel, RoundedCornerShape(14.dp)).padding(12.dp)) {
                            Text(if (line.fromUser) "YOU" else "JARVIS", color = Cyan, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(3.dp)); Text(line.text, color = Color(0xFFE5F5FF), fontSize = 14.sp)
                        }
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f), placeholder = { Text("Ask JARVIS…", color = SoftText) }, shape = RoundedCornerShape(16.dp), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Cyan, unfocusedBorderColor = Cyan.copy(alpha = .35f), focusedTextColor = Color.White, unfocusedTextColor = Color.White, cursorColor = Cyan), maxLines = 3)
                IconButton(onClick = { if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) { listening = true; onListen { result -> listening = false; if (result == "MIC_PERMISSION_NEEDED") history.add(ChatLine(false, "Please allow microphone permission.")) else input = result } } else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO) }, modifier = Modifier.size(48.dp).background(Color(0xFF10334A), CircleShape).border(1.dp, Cyan, CircleShape)) { Icon(Icons.Default.Mic, "Speak", tint = Cyan) }
                IconButton(onClick = { submit(input) }, modifier = Modifier.size(48.dp).background(Cyan, CircleShape)) { Icon(Icons.Default.Send, "Send", tint = Navy) }
            }
            Text("Mic uses Android speech service. Background wake-word listening is not enabled.", color = SoftText.copy(alpha = .7f), fontSize = 10.sp, modifier = Modifier.padding(top = 6.dp))
        }
        if (showSettings) AlertDialog(onDismissRequest = { showSettings = false }, containerColor = Panel, title = { Text("JARVIS Settings", color = Cyan) }, text = {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) { Text("Spoken replies", color = Color.White, modifier = Modifier.weight(1f)); Switch(checked = voiceReplies, onCheckedChange = { voiceReplies = it }) }
                Text("Speech language", color = Color.White); Spacer(Modifier.height(6.dp))
                listOf("Hindi / Hinglish", "English").forEach { item -> Row(verticalAlignment = Alignment.CenterVertically) { RadioButton(selected = language == item, onClick = { language = item }); Text(item, color = SoftText) } }
                Text("Language recognition depends on Android's speech provider.", color = SoftText, fontSize = 11.sp)
                TextButton(onClick = { history.clear(); history.add(ChatLine(false, "Conversation cleared.")) }) { Text("Clear conversation history", color = Cyan) }
            }
        }, confirmButton = { TextButton(onClick = { showSettings = false }) { Text("DONE", color = Cyan) } })
    }
}

# JARVIS — Native Android voice assistant

A starter native Android project built with Kotlin and Jetpack Compose for Android 8+ (tested target is Android 16-compatible APIs; it has not been built or device-tested in this environment). It uses Android's installed speech-recognition service and TextToSpeech, so basic commands do not require a paid AI API.

## Included features
- Dark, cyan hologram-inspired Compose UI
- Chat-style conversation during the current app session
- Microphone permission request and tap-to-talk via Android `SpeechRecognizer`
- Spoken responses via Android `TextToSpeech`
- Basic commands: open YouTube, search YouTube / Google, greeting, current time
- Settings for spoken replies and a language preference label
- GitHub Actions workflow to build and upload a debug APK artifact

## Honest limitations
- This is a basic command assistant, **not a general-purpose conversational AI model**. Unknown requests receive a simple fallback reply.
- Speech recognition availability, supported Hindi/Hinglish, and voice quality depend on the speech service and TTS voices installed on the phone; internet may be needed by the provider.
- It does **not** keep listening in the background, run a wake word, unlock the phone, or bypass Android lock-screen/microphone restrictions. The user must open the app and tap the microphone.
- Conversation history is in memory for the current app session only; it is not permanently stored.
- The settings language choice is currently a UI preference; recognition currently requests `hi-IN`.
- No paid API key is required for these basic local commands. Add an AI provider only if you want open-ended AI conversation; keep API keys out of source control.

## Build locally
1. Install Android Studio and JDK 17.
2. Open this folder as a project.
3. Install Android SDK Platform 36 if prompted.
4. Allow Gradle sync, then choose **Build > Build APK(s)**.
5. Debug APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Build on GitHub from your phone
1. Download and extract the project ZIP.
2. Create a new repository on GitHub.
3. Upload the **contents** of the extracted `JARVIS` folder to the repository root (including `.github/workflows/android.yml`). Do not upload only the ZIP file.
4. Open the repository's **Actions** tab and select **Build JARVIS APK**. Run workflow if it has not started automatically.
5. When complete, open the successful workflow run and download the `JARVIS-debug-apk` artifact. Extract that artifact ZIP to get `app-debug.apk`.
6. Open the APK on your phone and approve installation if Android asks. Only install APKs you built or trust.

## Permissions
The app requests microphone permission at the point of use. It does not request contacts, SMS, location, accessibility, or background microphone permissions.
